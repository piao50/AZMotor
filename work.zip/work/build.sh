#!/bin/sh

gcc modbus_test001.c -I /usr/local/include/modbus -L /usr/local/lib -lmodbus
